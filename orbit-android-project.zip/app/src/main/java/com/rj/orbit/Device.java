package com.rj.orbit;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.view.KeyEvent;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Every phone action the voice layer can ask for. Called from the WebView bridge thread. */
final class Device {
    private final Context ctx;
    private boolean torchOn = false;

    Device(Context c) { ctx = c; }

    static final class NeedPerm extends Exception {
        final String perm;
        NeedPerm(String p) { super(p); perm = p; }
    }

    static JSONObject res(boolean ok, String msg, Object... kv) {
        JSONObject j = new JSONObject();
        try {
            j.put("ok", ok);
            j.put("msg", msg);
            for (int i = 0; i + 1 < kv.length; i += 2) j.put((String) kv[i], kv[i + 1]);
        } catch (Exception ignored) { }
        return j;
    }

    String run(String name, String json) {
        try {
            JSONObject a = new JSONObject(json == null || json.isEmpty() ? "{}" : json);
            return dispatch(name, a).toString();
        } catch (NeedPerm p) {
            return res(false, "need_permission", "perm", p.perm).toString();
        } catch (Exception e) {
            return res(false, String.valueOf(e.getMessage())).toString();
        }
    }

    // ---------- helpers ----------
    private void start(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        OrbitAccess acc = OrbitAccess.instance;       // an enabled accessibility service may start
        (acc != null ? (Context) acc : ctx).startActivity(i);   // activities from the background
    }

    private boolean view(String url, String pkg) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        if (pkg != null) {
            i.setPackage(pkg);
            try { start(i); return true; } catch (Exception e) { i.setPackage(null); }
        }
        try { start(i); return true; } catch (Exception e) { return false; }
    }

    private boolean has(String perm) {
        return ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]", "");
    }

    private static int score(String label, String q) {
        if (label.isEmpty() || q.isEmpty()) return 0;
        if (label.equals(q)) return 100;
        if (label.startsWith(q)) return 80;
        if (label.contains(q)) return 60;
        if (q.contains(label) && label.length() > 2) return 40;
        return 0;
    }

    private JSONObject contact(String name) throws Exception {
        if (!has(Manifest.permission.READ_CONTACTS)) throw new NeedPerm("contacts");
        String q = norm(name);
        String bestName = null, bestNum = null;
        int bestScore = 0;
        Cursor c = ctx.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null);
        if (c != null) {
            try {
                while (c.moveToNext()) {
                    String dn = c.getString(0), num = c.getString(1);
                    int s = score(norm(dn), q);
                    if (s > bestScore || (s == bestScore && s > 0 && bestName != null && dn.length() < bestName.length())) {
                        bestScore = s; bestName = dn; bestNum = num;
                    }
                }
            } finally { c.close(); }
        }
        if (bestName == null) return res(false, "not_found");
        return res(true, "ok", "name", bestName, "number", bestNum);
    }

    private String waNumber(String n) {
        boolean plus = n.trim().startsWith("+");
        String d = n.replaceAll("\\D", "");
        if (!plus && d.length() == 10 && "IN".equals(Locale.getDefault().getCountry())) d = "91" + d;
        return d.replaceFirst("^0+", "");
    }

    private String torchId() throws Exception {
        CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
        for (String id : cm.getCameraIdList()) {
            Boolean f = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            if (f != null && f) return id;
        }
        return null;
    }

    private Intent settingsIntent(String page) {
        Uri pkg = Uri.parse("package:" + ctx.getPackageName());
        switch (page) {
            case "wifi": return new Intent(Settings.ACTION_WIFI_SETTINGS);
            case "bluetooth": return new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
            case "display": return new Intent(Settings.ACTION_DISPLAY_SETTINGS);
            case "sound": return new Intent(Settings.ACTION_SOUND_SETTINGS);
            case "battery": return new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS);
            case "apps": return new Intent(Settings.ACTION_APPLICATION_SETTINGS);
            case "location": return new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            case "accessibility": return new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            case "airplane": return new Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS);
            case "nfc": return new Intent(Settings.ACTION_NFC_SETTINGS);
            case "storage": return new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS);
            case "date": return new Intent(Settings.ACTION_DATE_SETTINGS);
            case "language": return new Intent(Settings.ACTION_LOCALE_SETTINGS);
            case "vpn": return new Intent(Settings.ACTION_VPN_SETTINGS);
            case "data": case "hotspot": return new Intent(Settings.ACTION_WIRELESS_SETTINGS);
            case "developer": return new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS);
            case "overlay": return new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg);
            case "battery_opt": return new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg);
            case "write": return new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg);
            case "app_details": return new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg);
            default: return new Intent(Settings.ACTION_SETTINGS);
        }
    }

    private OrbitAccess acc() throws Exception {
        OrbitAccess a = OrbitAccess.instance;
        if (a == null) throw new NeedPerm("accessibility");
        return a;
    }

    // ---------- dispatcher ----------
    private JSONObject dispatch(String name, JSONObject a) throws Exception {
        switch (name) {
            case "front": {
                start(new Intent(ctx, MainActivity.class).addFlags(
                        Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP));
                return res(true, "ok");
            }
            case "open_app": {
                PackageManager pm = ctx.getPackageManager();
                List<ResolveInfo> apps = pm.queryIntentActivities(
                        new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
                String q = norm(a.optString("name"));
                ResolveInfo best = null;
                int bs = 0;
                for (ResolveInfo r : apps) {
                    int s = score(norm(r.loadLabel(pm).toString()), q);
                    if (s > bs) { bs = s; best = r; }
                }
                if (best == null) return res(false, "not_found");
                start(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                        .setClassName(best.activityInfo.packageName, best.activityInfo.name));
                return res(true, "ok", "name", best.loadLabel(pm).toString());
            }
            case "contact": return contact(a.optString("name"));
            case "call": {
                if (!has(Manifest.permission.CALL_PHONE)) throw new NeedPerm("call");
                String n = a.optString("number").replaceAll("[^0-9+*#]", "");
                start(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n))));
                return res(true, "ok");
            }
            case "sms": {
                if (!has(Manifest.permission.SEND_SMS)) throw new NeedPerm("sms");
                String n = a.optString("number").replaceAll("[^0-9+]", "");
                SmsManager sm = Build.VERSION.SDK_INT >= 31 ? ctx.getSystemService(SmsManager.class)
                        : SmsManager.getDefault();
                ArrayList<String> parts = sm.divideMessage(a.optString("text"));
                sm.sendMultipartTextMessage(n, null, parts, null, null);
                return res(true, "ok");
            }
            case "whatsapp": {
                String url = "https://wa.me/" + waNumber(a.optString("number")) + "?text=" + Uri.encode(a.optString("text"));
                return view(url, "com.whatsapp") ? res(true, "ok") : res(false, "not_found");
            }
            case "flashlight": {
                String id = torchId();
                if (id == null) return res(false, "no_flash");
                boolean on = a.has("on") ? a.optBoolean("on") : !torchOn;
                ((CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE)).setTorchMode(id, on);
                torchOn = on;
                return res(true, "ok", "on", on);
            }
            case "volume": {
                AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
                int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                switch (a.optString("dir", "up")) {
                    case "up": am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); break;
                    case "down": am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); break;
                    case "mute": am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); break;
                    case "unmute": am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI); break;
                    case "max": am.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI); break;
                    case "min": am.setStreamVolume(AudioManager.STREAM_MUSIC, 1, AudioManager.FLAG_SHOW_UI); break;
                    case "set": {
                        int v = Math.max(0, Math.min(100, a.optInt("value", 50)));
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(v * max / 100f), AudioManager.FLAG_SHOW_UI);
                        break;
                    }
                    default: return res(false, "bad_args");
                }
                return res(true, "ok", "level", Math.round(100f * am.getStreamVolume(AudioManager.STREAM_MUSIC) / max));
            }
            case "media": {
                int code;
                switch (a.optString("cmd", "toggle")) {
                    case "play": code = KeyEvent.KEYCODE_MEDIA_PLAY; break;
                    case "pause": code = KeyEvent.KEYCODE_MEDIA_PAUSE; break;
                    case "next": code = KeyEvent.KEYCODE_MEDIA_NEXT; break;
                    case "previous": code = KeyEvent.KEYCODE_MEDIA_PREVIOUS; break;
                    case "stop": code = KeyEvent.KEYCODE_MEDIA_STOP; break;
                    default: code = KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
                }
                AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
                am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
                am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
                return res(true, "ok");
            }
            case "alarm": {
                start(new Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
                        .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "ORBIT"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true));
                return res(true, "ok");
            }
            case "timer": {
                start(new Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, Math.max(1, Math.min(86400, a.optInt("seconds", 60))))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "ORBIT"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true));
                return res(true, "ok");
            }
            case "navigate": {
                String q = Uri.encode(a.optString("query"));
                return view("google.navigation:q=" + q, "com.google.android.apps.maps") || view("geo:0,0?q=" + q, null)
                        ? res(true, "ok") : res(false, "not_found");
            }
            case "map": return view("geo:0,0?q=" + Uri.encode(a.optString("query")), null) ? res(true, "ok") : res(false, "not_found");
            case "web": return view("https://www.google.com/search?q=" + Uri.encode(a.optString("query")), null) ? res(true, "ok") : res(false, "not_found");
            case "youtube": return view("https://www.youtube.com/results?search_query=" + Uri.encode(a.optString("query")), "com.google.android.youtube") ? res(true, "ok") : res(false, "not_found");
            case "spotify": return view("spotify:search:" + Uri.encode(a.optString("query")), "com.spotify.music") ? res(true, "ok") : res(false, "not_found");
            case "settings": {
                start(settingsIntent(a.optString("page", "main")));
                return res(true, "ok");
            }
            case "camera": {
                start(new Intent("video".equals(a.optString("mode")) ? MediaStore.INTENT_ACTION_VIDEO_CAMERA
                        : MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA));
                return res(true, "ok");
            }
            case "brightness": {
                if (!Settings.System.canWrite(ctx)) throw new NeedPerm("write");
                int v = Math.max(1, Math.min(100, a.optInt("value", 50)));
                Settings.System.putInt(ctx.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                Settings.System.putInt(ctx.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, Math.round(v * 2.55f));
                return res(true, "ok");
            }
            // ---- everything below needs the accessibility service ----
            case "system": return acc().global(a.optString("cmd")) ? res(true, "ok") : res(false, "failed");
            case "qs": {
                String r = acc().tile(a.optString("label"), a.optString("want"));
                return r == null ? res(false, "not_found") : res(true, r);
            }
            case "tap": {
                String r = acc().tap(a.optString("text"));
                return r == null ? res(false, "not_found") : res(true, "ok", "label", r);
            }
            case "scroll": return acc().scroll(a.optString("dir", "down")) ? res(true, "ok") : res(false, "failed");
            case "swipe": return acc().swipe(a.optString("dir", "up")) ? res(true, "ok") : res(false, "failed");
            case "type": return acc().type(a.optString("text")) ? res(true, "ok") : res(false, "no_field");
            case "enter": return acc().enter() ? res(true, "ok") : res(false, "failed");
            case "read_screen": return res(true, "ok", "text", acc().readScreen());
            default: return res(false, "unknown_action");
        }
    }
}

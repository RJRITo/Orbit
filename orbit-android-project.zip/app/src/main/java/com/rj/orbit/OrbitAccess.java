package com.rj.orbit;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * Lets voice commands drive the whole phone: tap by label, scroll, type, back/home/recents,
 * quick settings, screenshots. The user must switch this on once in Settings > Accessibility.
 */
public class OrbitAccess extends AccessibilityService {
    static volatile OrbitAccess instance;

    @Override protected void onServiceConnected() { instance = this; }
    @Override public boolean onUnbind(Intent i) { instance = null; return super.onUnbind(i); }
    @Override public void onDestroy() { instance = null; super.onDestroy(); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }

    boolean global(String cmd) {
        int a;
        switch (cmd) {
            case "home": a = GLOBAL_ACTION_HOME; break;
            case "back": a = GLOBAL_ACTION_BACK; break;
            case "recents": a = GLOBAL_ACTION_RECENTS; break;
            case "notifications": a = GLOBAL_ACTION_NOTIFICATIONS; break;
            case "quick_settings": a = GLOBAL_ACTION_QUICK_SETTINGS; break;
            case "power": a = GLOBAL_ACTION_POWER_DIALOG; break;
            case "lock":
                if (Build.VERSION.SDK_INT < 28) return false;
                a = GLOBAL_ACTION_LOCK_SCREEN; break;
            case "screenshot":
                if (Build.VERSION.SDK_INT < 28) return false;
                a = GLOBAL_ACTION_TAKE_SCREENSHOT; break;
            default: return false;
        }
        return performGlobalAction(a);
    }

    private static String low(CharSequence c) { return c == null ? "" : c.toString().toLowerCase(); }

    private void collect(AccessibilityNodeInfo n, String t, List<AccessibilityNodeInfo> out) {
        if (n == null) return;
        if (low(n.getText()).contains(t) || low(n.getContentDescription()).contains(t)) out.add(n);
        for (int i = 0; i < n.getChildCount(); i++) collect(n.getChild(i), t, out);
    }

    private AccessibilityNodeInfo best(String t) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return null;
        List<AccessibilityNodeInfo> hits = new ArrayList<>();
        collect(root, t, hits);
        AccessibilityNodeInfo pick = null;
        int score = Integer.MAX_VALUE;
        for (AccessibilityNodeInfo n : hits) {
            String s = low(n.getText()).isEmpty() ? low(n.getContentDescription()) : low(n.getText());
            int sc = s.equals(t) ? 0 : s.length();
            if (n.isClickable() || n.getParent() != null) sc += 0;
            if (sc < score) { score = sc; pick = n; }
        }
        return pick;
    }

    /** Clicks the best node whose text/description contains t. Returns the node's label or null. */
    String tap(String t) {
        AccessibilityNodeInfo n = best(low(t).trim());
        if (n == null) return null;
        String label = !low(n.getText()).isEmpty() ? n.getText().toString() : String.valueOf(n.getContentDescription());
        AccessibilityNodeInfo c = n;
        while (c != null && !c.isClickable()) c = c.getParent();
        if (c == null) return null;
        return c.performAction(AccessibilityNodeInfo.ACTION_CLICK) ? label : null;
    }

    /** Quick-settings tile: labels like "wi-fi|wifi|internet". want = "on" | "off" | "". */
    String tile(String labels, String want) {
        for (String l : labels.split("\\|")) {
            AccessibilityNodeInfo n = best(low(l).trim());
            if (n == null) continue;
            String d = low(n.getContentDescription()) + " " + low(n.getText());
            if (!want.isEmpty()) {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\b(on|off)\\b").matcher(d);
                if (m.find() && m.group(1).equals(want)) return "already";
            }
            AccessibilityNodeInfo c = n;
            while (c != null && !c.isClickable()) c = c.getParent();
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "toggled";
        }
        return null;
    }

    String readScreen() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "";
        StringBuilder sb = new StringBuilder();
        dump(root, sb);
        return sb.length() > 4000 ? sb.substring(0, 4000) : sb.toString();
    }

    private void dump(AccessibilityNodeInfo n, StringBuilder sb) {
        if (n == null || sb.length() > 4000) return;
        CharSequence t = n.getText(), d = n.getContentDescription();
        if (t != null && t.length() > 0) sb.append(t).append('\n');
        else if (d != null && d.length() > 0) sb.append(d).append('\n');
        for (int i = 0; i < n.getChildCount(); i++) dump(n.getChild(i), sb);
    }

    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n) {
        if (n == null) return null;
        if (n.isScrollable()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findScrollable(n.getChild(i));
            if (r != null) return r;
        }
        return null;
    }

    boolean scroll(String dir) {
        AccessibilityNodeInfo s = findScrollable(getRootInActiveWindow());
        boolean fwd = dir.equals("down") || dir.equals("right");
        if (s != null && s.performAction(fwd ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) return true;
        // Fallback: a finger swipe in the opposite direction moves the content the right way.
        return swipe(dir.equals("down") ? "up" : dir.equals("up") ? "down" : dir.equals("right") ? "left" : "right");
    }

    /** Direction is the way the finger moves. */
    boolean swipe(String dir) {
        DisplayMetrics m = getResources().getDisplayMetrics();
        float w = m.widthPixels, h = m.heightPixels, x1 = w / 2, y1 = h / 2, x2 = x1, y2 = y1;
        switch (dir) {
            case "up": y1 = h * 0.75f; y2 = h * 0.25f; break;
            case "down": y1 = h * 0.25f; y2 = h * 0.75f; break;
            case "left": x1 = w * 0.8f; x2 = w * 0.2f; break;
            case "right": x1 = w * 0.2f; x2 = w * 0.8f; break;
            default: return false;
        }
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x2, y2);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 300)).build();
        return dispatchGesture(g, null, null);
    }

    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo n) {
        if (n == null) return null;
        if (n.isEditable()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findEditable(n.getChild(i));
            if (r != null) return r;
        }
        return null;
    }

    boolean type(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f == null) f = findEditable(root);
        if (f == null) return false;
        CharSequence cur = f.getText();
        String base = cur == null ? "" : cur.toString();
        if (f.isShowingHintText()) base = "";
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                base.isEmpty() ? text : base + " " + text);
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
    }

    boolean enter() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f != null && Build.VERSION.SDK_INT >= 30
                && f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId())) return true;
        return tap("search") != null || tap("send") != null || tap("go") != null;
    }
}

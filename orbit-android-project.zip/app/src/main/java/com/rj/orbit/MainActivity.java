package com.rj.orbit;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.SpeechService;
import org.vosk.android.StorageService;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * WebView shell + native voice engine. No timers, no licence checks: the app never expires.
 *  - Wake word: offline Vosk with a tiny grammar (silent, no beeps, no network).
 *  - Commands:  Android SpeechRecognizer (any language) or offline Vosk when "offline" is on.
 */
public class MainActivity extends Activity {
    private WebView web;
    private Device dev;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private SpeechRecognizer rec;
    private volatile int gen = 0;
    private long lastRms = 0;

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String ttsLang = "";

    private Model model;
    private volatile boolean wakeReady = false;
    private SpeechService wakeSvc, cmdSvc;
    private Recognizer wakeRec, cmdRec;
    private boolean wakeFired = false;
    private List<String> wakeWords = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        dev = new Device(this);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest r) { r.grant(r.getResources()); }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception ignored) { }
                return true;
            }
        });
        tts = new TextToSpeech(this, st -> { ttsReady = (st == TextToSpeech.SUCCESS); });
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { }
            @Override public void onDone(String id) { js("window.onNativeSpeakDone&&window.onNativeSpeakDone()"); }
            @Override public void onError(String id) { js("window.onNativeSpeakDone&&window.onNativeSpeakDone()"); }
        });
        loadModel();
        web.loadUrl("file:///android_asset/index.html");
    }

    // ---------- plumbing ----------
    private void js(final String code) { ui.post(() -> web.evaluateJavascript(code, null)); }

    private void err(int g, int code) { if (g == gen) js("window.onNativeError&&window.onNativeError(" + code + ")"); }

    private boolean granted(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    private void beep() {
        try {
            final ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_MUSIC, 70);
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 120);
            ui.postDelayed(tg::release, 500);
        } catch (Exception ignored) { }
    }

    // ---------- offline wake word (Vosk) ----------
    private void loadModel() {
        StorageService.unpack(this, "model-en-us", "model",
                m -> { model = m; wakeReady = true; js("window.onWakeReady&&window.onWakeReady(true)"); },
                e -> { wakeReady = false; js("window.onWakeReady&&window.onWakeReady(false)"); });
    }

    private void wakeStart(String csv) {
        if (model == null || !granted(Manifest.permission.RECORD_AUDIO)) return;
        wakeStop();
        try {
            JSONArray grammar = new JSONArray();
            wakeWords = new ArrayList<>();
            for (String p : csv.split(",")) {
                p = p.trim().toLowerCase(Locale.ROOT);
                if (!p.isEmpty()) { grammar.put(p); wakeWords.add(p); }
            }
            grammar.put("[unk]");
            wakeRec = new Recognizer(model, 16000.0f, grammar.toString());
            wakeSvc = new SpeechService(wakeRec, 16000.0f);
            wakeFired = false;
            wakeSvc.startListening(wakeListener);
        } catch (Exception e) {
            wakeStop();
            js("window.onWakeFail&&window.onWakeFail()");
        }
    }

    private void wakeStop() {
        try { if (wakeSvc != null) { wakeSvc.stop(); wakeSvc.shutdown(); } } catch (Exception ignored) { }
        try { if (wakeRec != null) wakeRec.close(); } catch (Exception ignored) { }
        wakeSvc = null;
        wakeRec = null;
    }

    private final org.vosk.android.RecognitionListener wakeListener = new org.vosk.android.RecognitionListener() {
        @Override public void onPartialResult(String h) { checkWake(h, "partial"); }
        @Override public void onResult(String h) { checkWake(h, "text"); }
        @Override public void onFinalResult(String h) { checkWake(h, "text"); }
        @Override public void onError(Exception e) { }
        @Override public void onTimeout() { }
    };

    private void checkWake(String h, String key) {
        if (wakeFired) return;
        try {
            String t = " " + new JSONObject(h).optString(key).toLowerCase(Locale.ROOT) + " ";
            for (String w : wakeWords) {
                if (t.contains(" " + w + " ")) {
                    wakeFired = true;
                    wakeStop();
                    beep();
                    js("window.onWake&&window.onWake()");
                    return;
                }
            }
        } catch (Exception ignored) { }
    }

    // ---------- command listening ----------
    private void stopCmd() {
        try { if (cmdSvc != null) { cmdSvc.stop(); cmdSvc.shutdown(); } } catch (Exception ignored) { }
        try { if (cmdRec != null) cmdRec.close(); } catch (Exception ignored) { }
        cmdSvc = null;
        cmdRec = null;
    }

    private void listen(final String lang, boolean offline) {
        final int g = ++gen;
        wakeStop();
        stopCmd();
        if (!granted(Manifest.permission.RECORD_AUDIO)) { askPerm("mic"); err(g, 9); return; }
        if (offline && model != null) offlineListen(g); else systemListen(lang, g);
    }

    private void systemListen(String lang, final int g) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { err(g, 12); return; }
        if (rec != null) rec.destroy();
        rec = SpeechRecognizer.createSpeechRecognizer(this);
        rec.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { }
            public void onBeginningOfSpeech() { }
            public void onRmsChanged(float v) {
                long now = System.currentTimeMillis();
                if (g == gen && now - lastRms > 80) { lastRms = now; js("window.onNativeLevel&&window.onNativeLevel(" + v + ")"); }
            }
            public void onBufferReceived(byte[] b) { }
            public void onEndOfSpeech() { }
            public void onError(int e) { err(g, e); }
            public void onResults(Bundle r) {
                ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (g == gen) js("window.onNativeResult&&window.onNativeResult(" + JSONObject.quote(l != null && !l.isEmpty() ? l.get(0) : "") + ")");
            }
            public void onPartialResults(Bundle r) {
                ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (g == gen && l != null && !l.isEmpty()) js("window.onNativePartial&&window.onNativePartial(" + JSONObject.quote(l.get(0)) + ")");
            }
            public void onEvent(int t, Bundle p) { }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200);
        rec.startListening(i);
    }

    private void offlineListen(final int g) {
        try {
            cmdRec = new Recognizer(model, 16000.0f);
            cmdSvc = new SpeechService(cmdRec, 16000.0f);
            cmdSvc.startListening(new org.vosk.android.RecognitionListener() {
                private boolean done = false;
                private void fin(String h) {
                    if (done || g != gen) return;
                    String t = "";
                    try { t = new JSONObject(h).optString("text"); } catch (Exception ignored) { }
                    if (t.isEmpty()) return;
                    done = true;
                    stopCmd();
                    js("window.onNativeResult&&window.onNativeResult(" + JSONObject.quote(t) + ")");
                }
                @Override public void onPartialResult(String h) {
                    if (g != gen) return;
                    try { js("window.onNativePartial&&window.onNativePartial(" + JSONObject.quote(new JSONObject(h).optString("partial")) + ")"); } catch (Exception ignored) { }
                }
                @Override public void onResult(String h) { fin(h); }
                @Override public void onFinalResult(String h) { fin(h); }
                @Override public void onError(Exception e) { if (!done) { done = true; stopCmd(); err(g, 3); } }
                @Override public void onTimeout() { if (!done) { done = true; stopCmd(); err(g, 6); } }
            }, 9000);
        } catch (Exception e) { err(g, 3); }
    }

    private void cancelListening() {
        gen++;
        if (rec != null) { try { rec.cancel(); } catch (Exception ignored) { } }
        stopCmd();
    }

    // ---------- permissions ----------
    private String[] permsFor(String name) {
        List<String> l = new ArrayList<>();
        boolean all = name.equals("all");
        if (all || name.equals("mic")) l.add(Manifest.permission.RECORD_AUDIO);
        if (all || name.equals("contacts")) l.add(Manifest.permission.READ_CONTACTS);
        if (all || name.equals("call")) l.add(Manifest.permission.CALL_PHONE);
        if (all || name.equals("sms")) l.add(Manifest.permission.SEND_SMS);
        if ((all || name.equals("notif")) && Build.VERSION.SDK_INT >= 33) l.add("android.permission.POST_NOTIFICATIONS");
        return l.toArray(new String[0]);
    }

    private void askPerm(final String name) {
        ui.post(() -> {
            List<String> need = new ArrayList<>();
            for (String p : permsFor(name)) if (!granted(p)) need.add(p);
            if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 100);
        });
    }

    private static String nameOf(String p) {
        if (p.equals(Manifest.permission.RECORD_AUDIO)) return "mic";
        if (p.equals(Manifest.permission.READ_CONTACTS)) return "contacts";
        if (p.equals(Manifest.permission.CALL_PHONE)) return "call";
        if (p.equals(Manifest.permission.SEND_SMS)) return "sms";
        return "notif";
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        for (int i = 0; i < perms.length && i < res.length; i++)
            js("window.onPermResult&&window.onPermResult('" + nameOf(perms[i]) + "'," + (res[i] == PackageManager.PERMISSION_GRANTED) + ")");
    }

    // ---------- lifecycle ----------
    @Override public void onBackPressed() { moveTaskToBack(true); }   // keep listening in the background

    @Override protected void onStop() {
        super.onStop();
        // Keep the page's JS running while the app is in the background (best effort).
        web.dispatchWindowVisibilityChanged(View.VISIBLE);
    }

    @Override protected void onDestroy() {
        wakeStop();
        stopCmd();
        if (rec != null) rec.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        stopService(new Intent(this, ListenService.class));
        super.onDestroy();
    }

    // ---------- JS bridge ----------
    private class Bridge {
        @JavascriptInterface public boolean hasNativeVoice() { return true; }
        @JavascriptInterface public boolean wakeAvailable() { return wakeReady; }
        @JavascriptInterface public void wakeStart(String csv) { ui.post(() -> MainActivity.this.wakeStart(csv)); }
        @JavascriptInterface public void wakeStop() { ui.post(() -> MainActivity.this.wakeStop()); }
        @JavascriptInterface public void startListening(String lang, boolean offline) { ui.post(() -> listen(lang, offline)); }
        @JavascriptInterface public void stopListening() { ui.post(() -> cancelListening()); }

        @JavascriptInterface public void speak(String text, double rate, String lang) {
            ui.post(() -> {
                if (!ttsReady) { js("window.onNativeSpeakDone&&window.onNativeSpeakDone()"); return; }
                MainActivity.this.wakeStop();
                if (!lang.equals(ttsLang)) { ttsLang = lang; tts.setLanguage(Locale.forLanguageTag(lang)); }
                tts.setSpeechRate((float) rate);
                tts.speak(text.length() > 3900 ? text.substring(0, 3900) : text, TextToSpeech.QUEUE_FLUSH, null, "orbit");
            });
        }
        @JavascriptInterface public void stopSpeaking() { ui.post(() -> { if (tts != null) tts.stop(); }); }

        @JavascriptInterface public String act(String name, String json) {
            String r = dev.run(name, json);
            try {
                JSONObject o = new JSONObject(r);
                if ("need_permission".equals(o.optString("msg"))) {
                    String p = o.optString("perm");
                    if (p.equals("contacts") || p.equals("call") || p.equals("sms")) askPerm(p);
                }
            } catch (Exception ignored) { }
            return r;
        }

        @JavascriptInterface public void requestPerm(String name) { askPerm(name); }

        @JavascriptInterface public void service(boolean on) {
            ui.post(() -> {
                Intent svc = new Intent(MainActivity.this, ListenService.class);
                try {
                    if (on && granted(Manifest.permission.RECORD_AUDIO)) {
                        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc); else startService(svc);
                    } else if (!on) stopService(svc);
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface public void dim(boolean on) {
            ui.post(() -> {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = on ? 0.02f : WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
                getWindow().setAttributes(lp);
            });
        }

        @JavascriptInterface public String battery() {
            Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int level = -1, scale = 100, st = -1;
            if (i != null) {
                level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            }
            return Device.res(true, "ok", "level", scale > 0 ? level * 100 / scale : level,
                    "charging", st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL).toString();
        }

        @JavascriptInterface public String status() {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            return Device.res(true, "ok",
                    "mic", granted(Manifest.permission.RECORD_AUDIO),
                    "contacts", granted(Manifest.permission.READ_CONTACTS),
                    "call", granted(Manifest.permission.CALL_PHONE),
                    "sms", granted(Manifest.permission.SEND_SMS),
                    "notif", Build.VERSION.SDK_INT < 33 || granted("android.permission.POST_NOTIFICATIONS"),
                    "accessibility", OrbitAccess.instance != null,
                    "overlay", Settings.canDrawOverlays(MainActivity.this),
                    "battery_opt", pm.isIgnoringBatteryOptimizations(getPackageName()),
                    "write", Settings.System.canWrite(MainActivity.this),
                    "wake", wakeReady).toString();
        }
    }
}

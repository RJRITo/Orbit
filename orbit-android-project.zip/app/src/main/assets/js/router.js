/* ORBIT router: turns a spoken sentence into {name, args} without needing the internet or an AI key. */
(() => {
const O = window.O;
const L = s => (s || '').toLowerCase();
const go = (name, args = {}) => ({ name, args });
const RULES = [];
const R = (re, fn) => RULES.push([new RegExp(re.source, 'i'), fn]);   // case-insensitive, original casing kept in captures

O.norm = t => (t || '').replace(/[“”"`]/g, '').replace(/[’‘]/g, "'").replace(/\b([ap])\.m\.?/gi, '$1m')
  .replace(/[.!?,;]+$/, '').replace(/\s+/g, ' ').trim()
  .replace(/^(?:hey |ok |okay )?(?:please|(?:can|could|would|will) you(?: please)?|i want you to|i need you to|i'd like you to|i would like you to)\s+/i, '')
  .replace(/\s+please$/i, '').trim();

const onOff = w => /^(on|enable|start|activate)$/i.test(w) ? true : /^(off|disable|stop|deactivate)$/i.test(w) ? false : undefined;
const WHAT = [[/wi-?fi/,'wifi'],[/bluetooth/,'bluetooth'],[/airplane|flight/,'airplane'],[/hotspot/,'hotspot'],[/location|gps/,'location'],
  [/do not disturb|dnd/,'dnd'],[/rotat/,'rotate'],[/battery saver/,'battery_saver'],[/nfc/,'nfc'],[/mobile data/,'data']];
const what = p => { for(const [re, k] of WHAT) if(re.test(L(p))) return k; return L(p); };
const PAGES = [[/wi-?fi/,'wifi'],[/bluetooth/,'bluetooth'],[/airplane|flight/,'airplane'],[/hotspot|tether/,'hotspot'],[/mobile data|data|sim|network/,'data'],
  [/display|screen/,'display'],[/sound|volume/,'sound'],[/battery/,'battery'],[/apps?|applications?/,'apps'],[/location|gps/,'location'],[/accessib/,'accessibility'],
  [/nfc/,'nfc'],[/storage/,'storage'],[/date|time/,'date'],[/language/,'language'],[/vpn/,'vpn'],[/developer/,'developer']];
const page = p => { for(const [re, k] of PAGES) if(re.test(L(p))) return k; return 'main'; };

/* ----- meta ----- */
R(/^(?:stop|cancel|never ?mind|quiet|be quiet|shut up|enough|stop talking)$/, () => go('stop'));
R(/^(?:go to sleep|sleep|that'?s all|that is all|thanks?(?: you)?(?: orbit)?|thank you(?: so much)?|good ?bye|bye(?: bye)?|ok(?:ay)? bye)$/, () => go('sleep'));
R(/^(?:stop listening|turn off (?:voice|listening|the microphone)|disable (?:voice|listening|wake word))$/, () => go('stop_listening'));
R(/^(?:clear|reset|delete|erase) (?:the |my )?(?:chat|conversation|history|memory)$/, () => go('clear_chat'));
R(/^(?:help|what can you do|what commands do you (?:know|have)|commands)$/, () => go('help'));
R(/^(?:grant|allow|give)(?: me)?(?: all)?(?: the)? permissions?$/, () => go('grant'));

/* ----- ORBIT screens ----- */
const OPEN = '(?:(?:show|open|go to|switch to|enter|launch|start|display)(?: me)?(?: the)? ?)?';
const VIEW = (alt, name) => R(new RegExp('^' + OPEN + '(?:' + alt + ')(?: screen| mode| view)?$'), () => go('view', { name }));
VIEW('hud|dashboard|cyber hud|heads[ -]?up display', 'hud');
VIEW('robot face|robot|face|eyes|your face', 'face');
VIEW('code editor|editor|coding mode|code mode|code screen|ide', 'code');
VIEW('standby|stand by|screensaver|screen saver|clock|night mode', 'standby');
R(/^(?:go |show |open |switch to |back to )?(?:the )?(?:orb|main screen|chat|orbit home|assistant)(?: screen)?$/, () => go('view', { name:'home' }));

/* ----- phone navigation ----- */
R(/^(?:home|go (?:to )?(?:the )?home(?: screen)?|press home|home button|home screen|show (?:the )?home screen|take me home)$/, () => go('system', { cmd:'home' }));
R(/^(?:go back|back|press back|back button|navigate back)$/, () => go('system', { cmd:'back' }));
R(/^(?:show |open )?(?:the )?(?:recent apps|recents|app switcher|multitasking|recent screen)$/, () => go('system', { cmd:'recents' }));
R(/^(?:show |open |pull down |check |see )?(?:the |my )?notifications?(?: panel| shade| tray| drawer)?$/, () => go('system', { cmd:'notifications' }));
R(/^(?:show |open |pull down )?(?:the )?quick settings(?: panel)?$/, () => go('system', { cmd:'quick_settings' }));
R(/^(?:take (?:a )?)?screenshot$|^(?:capture|grab) (?:the )?screen$/, () => go('system', { cmd:'screenshot' }));
R(/^lock(?: the)?(?: screen| phone| device)?$/, () => go('system', { cmd:'lock' }));
R(/^(?:show |open )?(?:the )?power menu$/, () => go('system', { cmd:'power' }));

/* ----- permissions and settings pages ----- */
R(/^(?:enable|turn on|allow|open|grant)(?: the)? (?:screen control|voice control|accessibility)(?: service| permission| access)?$/, () => go('settings', { page:'accessibility' }));
R(/^(?:allow|enable|grant|open) (?:brightness(?: control)?|write settings|system settings access)$/, () => go('settings', { page:'write' }));
R(/^(?:allow|enable|grant|open) (?:overlay|background launch|display over other apps|open apps from background)$/, () => go('settings', { page:'overlay' }));
R(/^(?:ignore|unrestrict|remove)(?: the)? battery (?:optimi[sz]ations?|restrictions?|limits?)$/, () => go('settings', { page:'battery_opt' }));
R(/^(?:open |show |go to )?(?:the )?(wi-?fi|bluetooth|display|sound|battery|apps?|applications?|location|accessibility|airplane mode|nfc|storage|date and time|language|vpn|hotspot|mobile data|developer|sim|network)(?: settings?| page| options)$/, m => go('settings', { page:page(m[1]) }));
R(/^(?:open |show )settings$/, () => go('settings', { page:'main' }));

/* ----- toggles and hardware ----- */
const TOG = 'wi-?fi|bluetooth|airplane mode|flight mode|hotspot|location|gps|do not disturb|dnd|auto-?rotate|rotation|battery saver|nfc|mobile data';
R(new RegExp('^(?:turn|switch|set|put)\\s+(on|off)\\s+(?:the |my )?(' + TOG + ')$'), m => go('toggle', { what:what(m[2]), on:onOff(m[1]) }));
R(new RegExp('^(?:turn|switch|set|put)\\s+(?:the |my )?(' + TOG + ')\\s+(on|off)$'), m => go('toggle', { what:what(m[1]), on:onOff(m[2]) }));
R(new RegExp('^(enable|disable|activate|deactivate)\\s+(?:the |my )?(' + TOG + ')$'), m => go('toggle', { what:what(m[2]), on:onOff(m[1]) }));
R(new RegExp('^(' + TOG + ')\\s+(on|off)$'), m => go('toggle', { what:what(m[1]), on:onOff(m[2]) }));
R(/^(?:turn|switch|put)\s+(on|off)\s+(?:the |my )?(?:flash ?light|torch|flash)$/, m => go('flashlight', { on:onOff(m[1]) }));
R(/^(?:turn|switch)\s+(?:the |my )?(?:flash ?light|torch)\s+(on|off)$/, m => go('flashlight', { on:onOff(m[1]) }));
R(/^(?:the |my )?(?:flash ?light|torch)(?: (on|off))?$/, m => go('flashlight', m[1] ? { on:onOff(m[1]) } : {}));

const VOLS = { maximum:'max', full:'max', minimum:'min' };
R(/^(?:volume|sound) ?(up|down|max|maximum|full|min|minimum|mute|unmute)$/, m => go('volume', { dir:VOLS[L(m[1])] || L(m[1]) }));
R(/^(?:turn|make|put|bring)(?: the| my)? (?:volume|sound) (up|down)$/, m => go('volume', { dir:L(m[1]) }));
R(/^(?:set |change |put )?(?:the )?volume (?:to |at )?(\d{1,3})(?: ?%| percent)?$/, m => go('volume', { dir:'set', value:+m[1] }));
R(/^(?:louder|turn it up|increase (?:the )?volume|raise (?:the )?volume|volume increase)$/, () => go('volume', { dir:'up' }));
R(/^(?:quieter|softer|turn it down|decrease (?:the )?volume|lower (?:the )?volume|volume decrease)$/, () => go('volume', { dir:'down' }));
R(/^(mute|unmute)(?: (?:the )?(?:phone|sound|volume))?$/, m => go('volume', { dir:L(m[1]) }));
R(/^(?:set |change |turn )?(?:the )?(?:screen )?brightness (?:to |at )?(\d{1,3})(?: ?%| percent)?$/, m => go('brightness', { value:+m[1] }));
const BR = { up:80, down:30, max:100, maximum:100, full:100, min:5, minimum:5, low:20, high:90 };
R(/^(?:set |turn )?(?:the )?(?:screen )?brightness (up|down|max|maximum|full|min|minimum|low|high)$/, m => go('brightness', { value:BR[L(m[1])] }));
R(/^(?:brighter|increase brightness)$/, () => go('brightness', { value:80 }));
R(/^(?:dimmer|decrease brightness|dim (?:the )?screen)$/, () => go('brightness', { value:25 }));

/* ----- media ----- */
R(/^(?:pause|resume|play|continue)(?: the)?(?: music| song| track| video| playback| media)?$/, m => go('media', { cmd:/pause/i.test(m[0]) ? 'pause' : 'play' }));
R(/^(?:next|skip)(?: the)?(?: song| track| video)?$/, () => go('media', { cmd:'next' }));
R(/^(?:previous|prev|last)(?: the)?(?: song| track| video)?$/, () => go('media', { cmd:'previous' }));
R(/^stop(?: the)? (?:music|song|track|video|playback|media)$/, () => go('media', { cmd:'stop' }));
R(/^(?:open |search )?you ?tube (?:search )?(?:for|and play|play) (.+)$/, m => go('youtube', { query:m[1] }));
R(/^play (.+?)(?: on (youtube|you tube|spotify))?$/, m => /spotify/i.test(m[2] || '') ? go('spotify', { query:m[1] }) : go('youtube', { query:m[1] }));

/* ----- time: timers, alarms ----- */
const NUMW = '\\d+(?:\\.\\d+)?|an?|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty|forty five|forty|sixty|half an?';
const WORDS = { a:1, an:1, one:1, two:2, three:3, four:4, five:5, six:6, seven:7, eight:8, nine:9, ten:10, fifteen:15, twenty:20, thirty:30, forty:40, 'forty five':45, sixty:60, 'half a':0.5, 'half an':0.5 };
const num = s => /^\d/.test(s) ? parseFloat(s) : WORDS[L(s)];
const UNIT = 'hours?|hrs?|minutes?|mins?|seconds?|secs?';
const mult = u => /^h/i.test(u) ? 3600 : /^m/i.test(u) ? 60 : 1;
const secs = m => Math.round(num(m[1]) * mult(m[2]) + (m[3] ? num(m[3]) * mult(m[4]) : 0));
R(new RegExp('^(?:set |start |create |put )?(?:a |an )?timer (?:for|of) (' + NUMW + ') ?(' + UNIT + ')(?: and (' + NUMW + ') ?(' + UNIT + '))?$'), m => go('timer', { seconds:secs(m) }));
R(new RegExp('^(?:set |start |create |put )?(?:a |an )?(' + NUMW + ') ?(' + UNIT + ')(?: and (' + NUMW + ') ?(' + UNIT + '))? timer$'), m => go('timer', { seconds:secs(m) }));
R(/^(?:cancel|stop|clear|delete) (?:all |my |the )?timers?$/, () => go('cancel_timers'));
const TIME = '(\\d{1,2})(?:[: .](\\d{2}))? ?(am|pm)?';
const alarm = m => {
  let h = +m[1], mi = +(m[2] || 0); const ap = L(m[3]);
  if(ap === 'pm' && h < 12) h += 12; else if(ap === 'am' && h === 12) h = 0;
  else if(!ap && h >= 1 && h <= 12){            // no am/pm said: take whichever comes next
    const now = new Date(), nm = now.getHours() * 60 + now.getMinutes(); let best = h % 12, bd = 1e9;
    for(const c of [h % 12, h % 12 + 12]){ let d = (c * 60 + mi - nm + 1440) % 1440; if(d === 0) d = 1440; if(d < bd){ bd = d; best = c; } }
    h = best;
  }
  return go('alarm', { hour:h, minute:mi, label:m[4] });
};
R(new RegExp('^(?:set|create|add|put)(?: an?)?(?: new)? alarm (?:for|at) ' + TIME + '(?: (?:called|named|labeled|for) (.+))?$'), alarm);
R(new RegExp('^wake me(?: up)? at ' + TIME + '$'), alarm);

/* ----- people ----- */
R(/^(?:send (?:a )?whatsapp(?: message)?(?: to)?|whatsapp(?: message)?(?: to)?|message on whatsapp) (.+?) (?:saying|that says|that|with message|:) (.+)$/, m => go('whatsapp', { to:m[1], text:m[2] }));
R(/^(?:send (?:a )?(?:text|sms|message|text message)(?: to)?|text|sms|message) (.+?) (?:saying|that says|that|with message|:) (.+)$/, m => go('sms', { to:m[1], text:m[2] }));
R(/^(?:call|phone|ring|dial)(?: up)? (.+)$/, m => go('call', { to:m[1] }));

/* ----- places and the web ----- */
R(/^(?:navigate(?: me)?(?: to)?|(?:get )?directions?(?: to)?|take me to|drive to|route to|how do i get to) (.+)$/, m => go('navigate', { query:m[1] }));
R(/^(?:show|find|search for|locate|where is)\s+(.+?)\s+(?:near me|nearby|on (?:the )?map|around here)$/, m => go('map', { query:m[1] }));
R(/^(?:search|google|look up|search for|search google for|search the web for|web search)\s+(?:for )?(.+)$/, m => go('web', { query:m[1] }));

/* ----- screen control ----- */
R(/^scroll (up|down|left|right)(?: a bit| more| please| a little)?$/, m => go('scroll', { dir:L(m[1]) }));
R(/^swipe (up|down|left|right)$/, m => go('swipe', { dir:L(m[1]) }));
R(/^(?:read|describe|summari[sz]e|what'?s on|what is on|what do you see on)\s*(?:the |my |this )?screen(?: aloud| out loud)?$/, () => go('read_screen'));
R(/^(?:press |hit )?(?:enter|submit)$/, () => go('enter'));
R(/^(?:type|dictate|input|enter text)\s+(.+)$/, m => go('type', { text:m[1] }));
R(/^(?:tap|click|press|touch|select|hit|choose)(?: on| the)?\s+(.+)$/, m => go('tap', { text:m[1].replace(/ button$/i, '') }));

/* ----- camera ----- */
R(/^(?:take|click|capture)(?: me)? (?:a )?(?:photo|picture|pic|selfie)$/, () => go('camera', { mode:'photo', shoot:true }));
R(/^(?:open )?(?:the )?camera$/, () => go('camera', { mode:'photo' }));
R(/^(?:record|take|start)(?: a)? video$/, () => go('camera', { mode:'video' }));

/* ----- info ----- */
R(/^(?:what'?s |what is |tell me |current )?(?:the )?time(?: is it| now| right now)?$|^what time is it(?: now)?$/, () => go('time'));
R(/^(?:what'?s |what is |tell me )?(?:today'?s |the )?(?:date|day)(?: today)?$|^what day is it(?: today)?$/, () => go('date'));
R(/^(?:what'?s |what is |how much is |check |tell me )?(?:my |the )?battery(?: level| percentage| percent| left| status| life)?$/, () => go('battery'));
R(/^(?:what'?s |what is |how'?s |tell me )?(?:the )?weather(?: like)?(?: (?:today|now|right now|outside))?(?: in (.+))?$/, m => go('weather', { city:m[1] }));
R(/^(?:set |change )?(?:my )?(?:home )?city (?:to |is )(.+)$/, m => go('set_city', { city:m[1] }));
R(/^(?:take a note|note|remember)(?: that)? (.+)$/, m => go('note', { text:m[1] }));
R(/^(?:read|show|what are) (?:my )?notes$/, () => go('notes_read'));
R(/^(?:delete|clear) (?:my |all )?notes$/, () => go('notes_clear'));
R(/^(?:calculate|compute|what is|what'?s|how much is)\s+(.+)$/, m => /\d/.test(m[1]) && /^[\d\s+\-*/().%^,x]+$|plus|minus|times|divided|over|multiplied/i.test(m[1]) ? go('calc', { expr:m[1] }) : null);

/* ----- build things ----- */
R(/^(?:write|create|make|build|generate|code|develop|program|design)\s+(?:me\s+)?(?:an?|some|the)?\s*.*\b(?:code|function|script|program|app|page|website|web ?site|html|css|javascript|python|java|class|game|calculator|component|snippet|algorithm|todo|landing|bot|api)\b.*$/, m => go('code_gen', { request:m[0] }));

/* ----- apps (keep last: "open X" is the catch-all) ----- */
R(/^(?:open|launch|start|run)\s+(.+)$/, m => go('open_app', { name:m[1].replace(/^(?:the |my )/i, '').replace(/ app$/i, '') }));

O.route = text => {
  const s = O.norm(text);
  if(O.curView === 'code' && O.codeRoute){ const c = O.codeRoute(s); if(c) return c; }
  for(const [re, fn] of RULES){ const m = re.exec(s); if(m){ const out = fn(m); if(out) return out; } }
  return null;
};
})();

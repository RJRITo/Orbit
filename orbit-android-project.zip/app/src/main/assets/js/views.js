/* ORBIT screens: view switching, cyber HUD, robot face, standby. */
(() => {
const O = window.O, $ = O.$, cfg = O.cfg;
const dpr = Math.min(devicePixelRatio || 1, 2);
const pad = n => String(n).padStart(2, '0');
O.VIEWS = ['home', 'hud', 'face', 'code', 'standby'];

const mk = id => {
  const c = $(id), g = c.getContext('2d'), o = { c, g, W:0, H:0 };
  o.fit = () => { const r = c.getBoundingClientRect(); o.W = r.width; o.H = r.height; c.width = Math.max(1, r.width*dpr); c.height = Math.max(1, r.height*dpr); g.setTransform(dpr,0,0,dpr,0,0); };
  return o;
};
const hud = mk('hud'), face = mk('face'), sb = mk('sb');
const sizeAll = () => { hud.fit(); face.fit(); sb.fit(); O.sizeOrb && O.sizeOrb(); };
addEventListener('resize', sizeAll);

/* ---------- switching ---------- */
const hooks = {
  standby:{
    enter(){ try{ O.native && O.native.dim(true); }catch(e){} tickClock(); },
    exit(){ try{ O.native && O.native.dim(false); }catch(e){} }
  }
};
O.view = name => {
  if(!O.VIEWS.includes(name)) return;
  const prev = O.curView;
  if(hooks[prev] && hooks[prev].exit) hooks[prev].exit();
  O.curView = name; document.body.dataset.view = name;
  O.VIEWS.forEach(v => $('v-' + v).classList.toggle('on', v === name));
  if(hooks[name] && hooks[name].enter) hooks[name].enter();
  requestAnimationFrame(sizeAll);
};

/* ---------- shared data for HUD + standby ---------- */
O.batt = null;
const pollBatt = async () => { O.batt = await O.getBattery(); };
setTimeout(pollBatt, 500); setInterval(() => { if(O.curView === 'hud' || O.curView === 'standby') pollBatt(); }, 20000);
const net = () => !navigator.onLine ? 'OFFLINE' : ((navigator.connection && navigator.connection.effectiveType) || 'ONLINE').toUpperCase();

const wv = new Array(48).fill(0);
const pushWave = t => { wv.push(Math.max(0.03, O.amp(t) * (0.6 + 0.4*Math.random()))); wv.shift(); };
function drawWave(o, x, y, w, h, rgb){
  const g = o.g, n = wv.length, bw = w/n;
  for(let i = 0; i < n; i++){
    const v = Math.min(1, wv[i]), bh = Math.max(2, v*h);
    g.fillStyle = `rgba(${rgb},${0.25 + 0.7*v})`; g.fillRect(x + i*bw + 1, y + (h-bh)/2, bw-2, bh);
  }
}

/* ---------- HUD ---------- */
function hudFrame(t){
  const { g, W, H } = hud; if(!W) return;
  g.clearRect(0, 0, W, H); pushWave(t);
  const c = O.COL[O.state] || O.COL.idle, col = a => `rgba(${c},${a})`;
  const cx = W/2, cy = H*0.34, R = Math.min(W*0.36, H*0.24), now = new Date(), sec = now.getSeconds();
  g.lineWidth = 2;
  [[1.0,[2,10],0.4,0.5],[0.82,[30,14],-0.6,0.7],[0.64,[6,6],1.0,0.5],[0.46,[60,20],-1.4,0.9]].forEach(([k, dash, sp, a]) => {
    g.strokeStyle = col(a); g.setLineDash(dash); g.lineDashOffset = -t*sp*20; g.beginPath(); g.arc(cx, cy, R*k, 0, 6.2832); g.stroke();
  });
  g.setLineDash([]);
  for(let i = 0; i < 60; i++){
    const a = i/60*6.2832 - 1.5708, major = i % 5 === 0, r1 = R*1.08, r2 = R*(major ? 1.2 : 1.15);
    g.strokeStyle = col(i <= sec ? 0.95 : 0.2); g.lineWidth = major ? 2 : 1;
    g.beginPath(); g.moveTo(cx + Math.cos(a)*r1, cy + Math.sin(a)*r1); g.lineTo(cx + Math.cos(a)*r2, cy + Math.sin(a)*r2); g.stroke();
  }
  g.textAlign = 'center'; g.fillStyle = col(1); g.font = `300 ${R*0.34}px system-ui`;
  g.fillText(pad(now.getHours()) + ':' + pad(now.getMinutes()), cx, cy + R*0.1);
  g.font = `${R*0.1}px system-ui`; g.fillStyle = col(0.7);
  g.fillText(now.toLocaleDateString([], { weekday:'short', day:'numeric', month:'short' }).toUpperCase(), cx, cy + R*0.32);
  const fs = Math.max(11, Math.min(14, W/28)), wx = O.weather ? `${O.weather.temp}° ${O.weather.desc}` : '—';
  const rows = [['LISTENER', cfg.alwaysOn ? 'ON' : 'OFF'], ['STATE', O.state.toUpperCase()],
    ['BATTERY', O.batt ? O.batt.level + '%' + (O.batt.charging ? ' ⚡' : '') : '—'], ['NETWORK', net()],
    ['SESSION', O.hms(O.uptime())], ['WEATHER', wx], ['TIMERS', String(O.timers.length)], ['LAST', (O.lastCmd || '—').slice(0, 20)]];
  g.font = `${fs}px ui-monospace, Menlo, monospace`;
  const y0 = cy + R*1.55, lh = fs*1.9;
  rows.forEach(([k, v], i) => {
    const colx = i % 2, x = W*0.07 + colx*W*0.48, y = y0 + Math.floor(i/2)*lh;
    g.textAlign = 'left'; g.fillStyle = col(0.55); g.fillText(k, x, y);
    g.fillStyle = col(1); g.fillText(v, x + fs*6.2, y);
  });
  drawWave(hud, W*0.07, H - 56, W*0.86, 40, c.join(','));
}

/* ---------- robot face ---------- */
const S = { blinkT:-9, nextBlink:1, gx:0, gy:0, tgx:0, tgy:0, nextLook:1, mood:'', until:0 };
O.emote = m => { S.mood = m; S.until = performance.now()/1000 + 2.5; };
$('face').addEventListener('click', () => O.emote('happy'));
function rr(g, x, y, w, h, r){
  r = Math.min(r, w/2, h/2); g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
}
function faceFrame(t){
  const { g, W, H } = face; if(!W) return;
  g.clearRect(0, 0, W, H);
  const c = O.COL[O.state] || O.COL.idle, rgb = `rgb(${c})`, st = O.state;
  if(t > S.nextBlink){ S.blinkT = t; S.nextBlink = t + 2 + Math.random()*3.5; }
  const open = 1 - Math.max(0, 1 - Math.abs((t - S.blinkT) - 0.09)/0.09);
  if(t > S.nextLook){ S.tgx = (Math.random() - 0.5)*2; S.tgy = (Math.random() - 0.5)*1.2; S.nextLook = t + 1 + Math.random()*2.5; }
  if(st === 'thinking'){ S.tgx = 0.7*Math.sin(t*1.4); S.tgy = -0.9; }
  if(st === 'listening'){ S.tgx = 0; S.tgy = 0; }
  S.gx += (S.tgx - S.gx)*0.1; S.gy += (S.tgy - S.gy)*0.1;
  const happy = S.mood === 'happy' && t < S.until;
  const ex = W*0.23, ey = H*0.4, ew = W*0.17, base = H*0.17*(st === 'listening' ? 1.25 : st === 'thinking' ? 0.8 : st === 'standby' ? 0.55 : 1);
  g.shadowBlur = 28; g.shadowColor = rgb; g.fillStyle = rgb; g.strokeStyle = rgb; g.lineWidth = Math.max(4, W*0.018); g.lineCap = 'round';
  for(const s of [-1, 1]){
    const x = W/2 + s*ex;
    if(happy){ g.beginPath(); g.arc(x, ey + base*0.3, ew*0.45, Math.PI*1.1, Math.PI*1.9); g.stroke(); }
    else {
      const eh = Math.max(3, base*(0.1 + 0.9*open));
      rr(g, x - ew/2 + S.gx*ew*0.2, ey - eh/2 + S.gy*base*0.25, ew, eh, ew*0.35); g.fill();
    }
  }
  if(st === 'thinking'){ g.beginPath(); g.moveTo(W/2 + ex - ew*0.6, ey - base*0.9); g.lineTo(W/2 + ex + ew*0.6, ey - base*1.1); g.stroke(); }
  const my = H*0.72, mw = W*0.24;
  const mo = st === 'speaking' ? (0.1 + 0.9*Math.abs(Math.sin(t*9)*Math.sin(t*3.1)))*H*0.07 : st === 'listening' ? H*0.012 : 0;
  g.beginPath();
  if(mo > 3){ g.ellipse(W/2, my, mw*0.5, mo, 0, 0, 6.2832); g.fill(); }
  else { const sm = happy ? H*0.05 : st === 'standby' ? 0 : H*0.015; g.moveTo(W/2 - mw/2, my); g.quadraticCurveTo(W/2, my + sm*2, W/2 + mw/2, my); g.stroke(); }
  g.shadowBlur = 0;
  g.fillStyle = `rgba(${c},0.6)`; g.font = `${Math.max(11, W/30)}px ui-monospace, monospace`; g.textAlign = 'center';
  g.fillText(st === 'standby' ? 'say “hey orbit”' : st.toUpperCase(), W/2, H - 24);
}

/* ---------- standby ---------- */
function tickClock(){
  const n = new Date();
  $('sbclock').textContent = pad(n.getHours()) + ':' + pad(n.getMinutes());
  $('sbdate').textContent = n.toLocaleDateString([], { weekday:'long', day:'numeric', month:'long' });
  $('sbhint').textContent = O.state === 'standby' || O.state === 'idle' ? 'say “' + (O.wakeList()[0] || 'orbit') + '”' : O.state;
}
setInterval(() => { if(O.curView === 'standby') tickClock(); }, 1000);
$('v-standby').addEventListener('click', () => O.view('home'));
function sbFrame(t){ const { g, W, H } = sb; if(!W) return; g.clearRect(0, 0, W, H); pushWave(t); drawWave(sb, 0, 0, W, H, '28,110,134'); }

/* ---------- one animation loop for all of them ---------- */
(function loop(ts){
  requestAnimationFrame(loop);
  const t = ts/1000;
  if(O.curView === 'hud') hudFrame(t); else if(O.curView === 'face') faceFrame(t); else if(O.curView === 'standby') sbFrame(t);
})(0);
setTimeout(sizeAll, 0);
})();

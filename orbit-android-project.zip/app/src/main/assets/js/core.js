/* ORBIT core: state, voice in/out, wake word + session loop, settings. No timers limit anything here. */
(() => {
const O = window.O = {};
const $ = O.$ = id => document.getElementById(id);
O.sleep = ms => new Promise(r => setTimeout(r, ms));

const store = O.store = {
  get(k, d){ try{ const v = localStorage.getItem('orbit.'+k); return v === null ? d : JSON.parse(v); }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem('orbit.'+k, JSON.stringify(v)); }catch(e){} }
};

O.native = (() => { try { return (typeof Android !== 'undefined' && Android.hasNativeVoice()) ? Android : null; } catch(e){ return null; } })();

O.PERSONA = "You are ORBIT, a calm, witty voice assistant. Reply in 1-3 short spoken-style sentences unless asked for detail. No markdown, no emojis. Reply in the language the user speaks.";
const DEF = { provider:'groq', key:'', model:'', persona:O.PERSONA, rate:1, speakOn:true, lang:'en-IN',
  wake:'orbit, hey orbit, jarvis, hey jarvis', alwaysOn:!!O.native, follow:true, confirm:true, offline:false, city:'' };
const cfg = O.cfg = {};
for(const k in DEF) cfg[k] = store.get(k, DEF[k]);
if(!cfg.persona) cfg.persona = O.PERSONA;
O.saveCfg = () => { for(const k in DEF) store.set(k, cfg[k]); };

/* ---------- session clock: counts UP, nothing ever expires ---------- */
const t0 = Date.now();
O.uptime = () => Math.floor((Date.now()-t0)/1000);
O.hms = s => { const p = n => String(n).padStart(2,'0'); return p(Math.floor(s/3600))+':'+p(Math.floor(s/60)%60)+':'+p(s%60); };
setInterval(() => { $('up').textContent = O.hms(O.uptime()); }, 1000);

/* ---------- chat log ---------- */
O.add = (cls, text) => {
  const d = document.createElement('div'); d.className = 'msg '+cls; d.textContent = text;
  const l = $('log'); l.appendChild(d); l.scrollTop = l.scrollHeight;
  while(l.children.length > 60) l.removeChild(l.firstChild);
  return d;
};
O.sys = text => O.add('sys', text);

/* ---------- state ---------- */
O.state = 'idle'; O.level = 0; O.inSession = false; O.busy = false; O.curView = 'home'; O.wakeReady = false; O.fbRunning = false;
const LABEL = { standby:'say “hey orbit”' };
O.restState = () => (O.native && cfg.alwaysOn && !O.inSession) ? 'standby' : 'idle';
O.setState = s => {
  O.state = s; $('state').textContent = LABEL[s] || s; $('mic').classList.toggle('on', s === 'listening');
};
O.updatePill = () => {
  const on = cfg.alwaysOn && (O.native || O.fbRunning);
  $('pill').classList.toggle('on', !!on);
  $('pill').textContent = on ? '● say “'+(O.wakeList()[0] || 'orbit')+'”' : '● voice off';
};

/* ---------- orb (home screen) ---------- */
const cv = $('cv'), g = cv.getContext('2d');
let W = 0, H = 0; const dpr = Math.min(devicePixelRatio || 1, 2);
const sizeOrb = () => { const r = cv.getBoundingClientRect(); W = r.width; H = r.height; cv.width = W*dpr; cv.height = H*dpr; g.setTransform(dpr,0,0,dpr,0,0); };
addEventListener('resize', sizeOrb); setTimeout(sizeOrb, 0);
O.sizeOrb = sizeOrb;
const N = 420, pts = [];
for(let i=0;i<N;i++){ const y = 1-(i/(N-1))*2, r = Math.sqrt(1-y*y), th = i*2.399963; pts.push([Math.cos(th)*r, y, Math.sin(th)*r]); }
let rot = 0, smooth = 0, drag = 0, dragV = 0;
cv.addEventListener('pointerdown', e => { drag = e.clientX; });
cv.addEventListener('pointermove', e => { if(drag){ dragV = (e.clientX-drag)*0.01; drag = e.clientX; } });
addEventListener('pointerup', () => drag = 0);
O.COL = { idle:[39,211,255], standby:[30,120,160], listening:[80,255,170], thinking:[122,92,255], speaking:[255,180,60] };
O.amp = t => O.state==='listening' ? 0.25+O.level*0.9
  : O.state==='speaking' ? 0.3+0.25*Math.abs(Math.sin(t*7))+0.15*Math.sin(t*13)
  : O.state==='thinking' ? 0.2+0.1*Math.sin(t*10) : 0.08*Math.sin(t*1.5);
function orbFrame(ts){
  requestAnimationFrame(orbFrame);
  if(O.curView !== 'home') return;
  const t = ts/1000, c = O.COL[O.state] || O.COL.idle;
  smooth += (O.amp(t)-smooth)*0.15;
  rot += (O.state==='thinking' ? 0.03 : 0.006) + dragV; dragV *= 0.95;
  g.clearRect(0,0,W,H);
  const cx = W/2, cy = H/2-4, R = Math.min(W,H)*0.34;
  const gr = g.createRadialGradient(cx,cy,R*0.2,cx,cy,R*1.9);
  gr.addColorStop(0,`rgba(${c},${0.18+smooth*0.2})`); gr.addColorStop(1,'rgba(0,0,0,0)');
  g.fillStyle = gr; g.fillRect(0,0,W,H);
  const ca = Math.cos(rot), sa = Math.sin(rot), ct = Math.cos(0.35), st = Math.sin(0.35);
  for(let i=0;i<N;i++){
    let [x,y,z] = pts[i]; const wob = 1+smooth*0.35*Math.sin(i*0.37+t*5);
    x*=wob; y*=wob; z*=wob;
    const x1 = x*ca+z*sa, z1 = -x*sa+z*ca, y1 = y*ct-z1*st, z2 = y*st+z1*ct;
    const k = 1/(1.9-z2*0.5), px = cx+x1*R*k*1.5, py = cy+y1*R*k*1.5, d = (z2+1)/2;
    g.fillStyle = `rgba(${c},${0.25+0.75*d})`; g.beginPath(); g.arc(px,py,(0.8+1.6*d)*k*1.3,0,6.2832); g.fill();
  }
}
requestAnimationFrame(orbFrame);

/* ---------- speech out ---------- */
let speakDone = null;
O.speak = text => new Promise(res => {
  if(!cfg.speakOn || !text){ res(); return; }
  O.setState('speaking');
  let fin = false, wd;
  const done = () => {
    if(fin) return; fin = true; clearTimeout(wd); speakDone = null;
    O.setState(O.inSession ? 'idle' : O.restState());
    res();
    if(!O.inSession) O.armWake();
  };
  speakDone = done;
  wd = setTimeout(done, 5000 + text.length*110);   // never let a lost callback freeze the loop
  if(O.native){ window.onNativeSpeakDone = done; O.native.speak(text, cfg.rate, cfg.lang); return; }
  if(!('speechSynthesis' in window)){ done(); return; }
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text); u.rate = cfg.rate; u.lang = cfg.lang; u.onend = done; u.onerror = done;
  speechSynthesis.speak(u);
});
O.stopSpeaking = () => { try{ O.native ? O.native.stopSpeaking() : speechSynthesis.cancel(); }catch(e){} if(speakDone) speakDone(); };
O.say = async text => { if(!text) return; O.add('ai', text); await O.speak(text.replace(/[*_`#]/g,'')); };

/* ---------- speech in ---------- */
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let pending = null, webRec = null;
O.abortListen = () => {
  if(pending) pending.finish({ text:'', err:'aborted' });
  try{ O.native ? O.native.stopListening() : webRec && webRec.abort(); }catch(e){}
};
O.listenOnce = ({ short=false, state='listening' } = {}) => new Promise(res => {
  if(pending) pending.finish({ text:'', err:'replaced' });
  let done = false, wd;
  const finish = r => { if(done) return; done = true; clearTimeout(wd); pending = null; O.level = 0; $('partial').textContent = ''; res(r); };
  pending = { finish };
  O.setState(state);
  wd = setTimeout(() => { try{ O.native ? O.native.stopListening() : webRec && webRec.abort(); }catch(e){} finish({ text:'', err:'timeout' }); }, short ? 9000 : 15000);
  if(O.native){
    window.onNativePartial = t => { $('partial').textContent = t; };
    window.onNativeLevel = v => { O.level = Math.max(0, Math.min(1, (v+2)/12)); };
    window.onNativeResult = t => finish({ text:(t||'').trim() });
    window.onNativeError = code => finish({ text:'', err:code, fatal: code === 9 });
    O.native.startListening(cfg.lang, !!cfg.offline);
    return;
  }
  if(!SR){ finish({ text:'', err:'unsupported', fatal:true }); return; }
  const r = webRec = new SR(); r.lang = cfg.lang; r.interimResults = true; let txt = '';
  r.onresult = e => { let t = ''; for(const x of e.results) t += x[0].transcript; txt = t; $('partial').textContent = t; O.level = 0.5; };
  r.onerror = e => finish({ text:'', err:e.error, fatal: e.error === 'not-allowed' });
  r.onend = () => finish({ text:txt.trim() });
  try{ r.start(); }catch(e){ finish({ text:'', err:'start' }); }
});
const micMsg = err => err === 9 || err === 'not-allowed' ? 'Microphone permission is missing. Open settings and tap the red Microphone chip.'
  : err === 'unsupported' ? 'Voice input is not supported here. Type instead.' : 'Voice input error ('+err+').';

/* ---------- wake word ---------- */
O.wakeList = () => cfg.wake.split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
const ALIAS = { orbit:['orbit','orbits','or bit','orbitt'], jarvis:['jarvis','jarvas','jar vis'] };
O.wakeMatch = text => {
  const t = (text||'').toLowerCase().replace(/[^\p{L}\p{N}\s']/gu,' ').replace(/\s+/g,' ').trim();
  const words = new Set();
  for(const p of O.wakeList()){ const w = p.split(' ').pop(); (ALIAS[w] || [w]).forEach(a => words.add(a)); }
  if(!words.size) return null;
  const alt = [...words].map(w => w.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|');
  const lead = new RegExp('^(?:(?:hey|hi|ok|okay|hello|hay)\\s+)?(?:'+alt+')\\b\\s*(.*)$').exec(t);
  if(lead) return lead[1];
  const tail = new RegExp('^(.*?)\\s+(?:(?:hey|hi|ok|okay)\\s+)?(?:'+alt+')$').exec(t);
  return tail ? tail[1] : null;
};

O.armWake = () => {
  if(!cfg.alwaysOn || O.inSession) return;
  if(O.native && O.wakeReady){ try{ O.native.wakeStart(O.wakeList().join(',')); }catch(e){} O.setState('standby'); }
  else if(!O.fbRunning && (O.native || SR)) O.fallbackLoop();
  O.updatePill();
};
O.disarmWake = () => { try{ O.native && O.native.wakeStop(); }catch(e){} if(!O.inSession) O.setState('idle'); O.updatePill(); };

/* One conversation: handle commands back-to-back until the user goes quiet, then sleep. */
O.session = async first => {
  if(O.inSession) return;
  O.abortListen();
  O.inSession = true;
  try{
    if(first) await O.handle(first);
    while(O.inSession && (first === undefined || cfg.follow)){
      first = null;
      const r = await O.listenOnce();
      if(r.fatal){ O.sys(micMsg(r.err)); break; }
      if(!r.text) break;
      await O.handle(r.text);
      if(!cfg.follow) break;
    }
  } finally {
    O.inSession = false; O.setState(O.restState()); O.armWake();
  }
};
O.endSession = () => { O.inSession = false; O.abortListen(); };

/* Fallback when the offline wake model is missing: poll the system recogniser (beeps on some phones). */
O.fallbackLoop = async () => {
  if(O.fbRunning) return; O.fbRunning = true; O.updatePill();
  let fails = 0;
  while(cfg.alwaysOn && !O.wakeReady){
    if(O.inSession){ await O.sleep(300); continue; }
    const r = await O.listenOnce({ state:'standby' });
    if(O.inSession) continue;
    if(r.fatal){ O.sys(micMsg(r.err)); cfg.alwaysOn = false; break; }
    if(!r.text){ fails++; await O.sleep(Math.min(250*fails, 3000)); continue; }
    fails = 0;
    const w = O.wakeMatch(r.text);
    if(w === null) continue;
    await O.session(w || undefined);
  }
  O.fbRunning = false; O.updatePill();
};

/* ---------- boot ---------- */
O.boot = () => {
  window.onWake = () => { if(!O.inSession) O.session(); };
  window.onWakeReady = ok => {
    O.wakeReady = !!ok;
    if(!ok) O.sys('Offline wake-word model not found — falling back to the system recogniser.');
    O.armWake();
  };
  window.onWakeFail = () => { O.wakeReady = false; O.armWake(); };
  window.onPermResult = (name, ok) => {
    O.renderStatus();
    if(name === 'mic' && ok){ O.native.service(cfg.alwaysOn); O.armWake(); }
  };
  O.updatePill(); O.renderStatus();
  if(!O.native) return;
  let st = {}; try{ st = JSON.parse(O.native.status()); }catch(e){}
  O.wakeReady = !!st.wake;
  if(!store.get('onboarded', false)){
    store.set('onboarded', true);
    O.sys('Welcome. Allow the permissions that pop up, then say “hey orbit”.');
    O.native.requestPerm('all');
    return;
  }
  if(!st.mic){ O.sys('Allow the microphone to start voice control.'); O.native.requestPerm('mic'); return; }
  O.native.service(cfg.alwaysOn); O.armWake();
};

/* ---------- controls ---------- */
$('mic').onclick = () => { if(O.inSession){ O.endSession(); } else { O.stopSpeaking(); O.session(); } };
$('pill').onclick = () => {
  cfg.alwaysOn = !cfg.alwaysOn; O.saveCfg();
  if(O.native) O.native.service(cfg.alwaysOn);
  cfg.alwaysOn ? O.armWake() : O.disarmWake();
  O.updatePill(); O.sys(cfg.alwaysOn ? 'Listening for the wake word.' : 'Wake word off. Tap the mic to talk.');
};
$('send').onclick = () => { const v = $('txt').value; $('txt').value = ''; if(v.trim()) O.handle(v); };
$('txt').addEventListener('keydown', e => { if(e.key === 'Enter') $('send').click(); });
$('brand').onclick = () => O.view && O.view('home');

/* ---------- settings sheet ---------- */
const TEXT = ['provider','key','model','persona','wake','lang','city'], BOOL = ['alwaysOn','follow','confirm','offline','speakOn'];
O.renderStatus = () => {
  const box = $('status');
  if(!O.native){ box.innerHTML = '<span class="st">Browser preview — phone control needs the Android app</span>'; return; }
  let st = {}; try{ st = JSON.parse(O.native.status()); }catch(e){}
  const items = [['mic','Microphone','perm:mic'],['contacts','Contacts','perm:contacts'],['call','Calls','perm:call'],['sms','SMS','perm:sms'],
    ['notif','Notifications','perm:notif'],['accessibility','Screen control','set:accessibility'],['overlay','Open apps from background','set:overlay'],
    ['battery_opt','Battery unrestricted','set:battery_opt'],['write','Brightness','set:write'],['wake','Offline wake word','']];
  box.innerHTML = items.map(([k,l,a]) => `<span class="st ${st[k]?'ok':''}" data-a="${a}">${st[k]?'✓':'✗'} ${l}</span>`).join('');
  box.querySelectorAll('.st:not(.ok)').forEach(el => el.onclick = () => {
    const a = el.dataset.a; if(!a) return; const [t, n] = a.split(':');
    t === 'perm' ? O.native.requestPerm(n) : O.native.act('settings', JSON.stringify({ page:n }));
  });
};
O.openSettings = () => {
  TEXT.forEach(k => $(k).value = cfg[k]); BOOL.forEach(k => $(k).checked = !!cfg[k]); $('rate').value = cfg.rate;
  O.renderStatus(); $('sheet').classList.add('open');
};
$('gear').onclick = O.openSettings;
$('sheet').addEventListener('click', e => { if(e.target.id === 'sheet') $('sheet').classList.remove('open'); });
$('clear').onclick = () => { O.clearChat && O.clearChat(); };
$('save').onclick = () => {
  const was = cfg.alwaysOn;
  TEXT.forEach(k => cfg[k] = $(k).value.trim()); BOOL.forEach(k => cfg[k] = $(k).checked); cfg.rate = parseFloat($('rate').value);
  if(!cfg.persona) cfg.persona = O.PERSONA; if(!cfg.wake) cfg.wake = DEF.wake;
  O.saveCfg(); $('sheet').classList.remove('open'); O.sys('Settings saved.');
  if(O.native && was !== cfg.alwaysOn) O.native.service(cfg.alwaysOn);
  cfg.alwaysOn ? O.armWake() : O.disarmWake();
  O.updatePill();
};
})();

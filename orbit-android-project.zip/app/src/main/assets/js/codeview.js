/* ORBIT voice code editor: dictate, generate, run, save — all by voice. */
(() => {
const O = window.O, $ = O.$, A = O.actions, store = O.store, cfg = O.cfg;
const ta = $('code'), go = (name, args = {}) => ({ name, args });
let undo = [];
const code = O.code = {
  get: () => ta.value,
  set(v){ undo.push(ta.value); if(undo.length > 20) undo.shift(); ta.value = v; },
};
const isHtml = s => /<\s*(html|body|div|script|style|h1|h2|p|canvas|button|svg)\b/i.test(s);

function run(){
  const src = ta.value; $('con').textContent = '';
  if(!src.trim()) return 'The editor is empty.';
  const pyish = /^\s*(def \w+\(|import \w+\s*$|from \w+ import|print\()/m.test(src) && !/\b(function|const|let|var|console)\b|=>/.test(src);
  if(pyish) return 'That looks like Python. I can only run HTML and JavaScript here, but I can still write and explain it.';
  const shim = '<script>(function(){var s=function(t){parent.postMessage({orbitLog:t},"*")};var f=function(){s([].map.call(arguments,function(a){try{return typeof a==="object"?JSON.stringify(a):String(a)}catch(e){return String(a)}}).join(" "))};console.log=f;console.error=f;onerror=function(m,u,l){s("Error: "+m+" (line "+l+")")};})();<\/script>';
  $('pv').srcdoc = isHtml(src)
    ? (/<head[^>]*>/i.test(src) ? src.replace(/<head[^>]*>/i, m => m + shim) : shim + src)
    : shim + '<script>try{' + src.replace(/<\/script/gi, '<\\/script') + '\n}catch(e){console.log("Error: "+e.message)}<\/script>';
  return 'Running.';
}
addEventListener('message', e => {
  if(e.data && typeof e.data.orbitLog === 'string'){ const c = $('con'); c.textContent += e.data.orbitLog + '\n'; c.scrollTop = 1e9; }
});

const files = () => store.get('files', {});
const fileKey = n => (n || '').toLowerCase().trim().replace(/\s+/g, '-');

A.code_run = async () => run();
A.code_copy = async () => {
  try{ await navigator.clipboard.writeText(ta.value); }catch(e){ ta.select(); try{ document.execCommand('copy'); }catch(x){} }
  return 'Copied.';
};
A.code_undo = async () => { if(!undo.length) return 'Nothing to undo.'; ta.value = undo.pop(); return 'Undone.'; };
A.code_clear = async () => { code.set(''); $('pv').srcdoc = ''; $('con').textContent = ''; return 'Cleared. Say undo to bring it back.'; };
A.code_save = async ({ name }) => {
  if(!ta.value.trim()) return 'Nothing to save.';
  const k = fileKey(name) || 'untitled-' + (Object.keys(files()).length + 1);
  const f = files(); f[k] = ta.value; store.set('files', f); return `Saved as ${k.replace(/-/g, ' ')}.`;
};
A.code_load = async ({ name }) => { const f = files(), k = fileKey(name); if(!(k in f)) return `I have no file called ${name}.`; code.set(f[k]); return `Opened ${name}.`; };
A.code_list = async () => { const k = Object.keys(files()); return k.length ? 'Your files: ' + k.map(x => x.replace(/-/g, ' ')).join(', ') + '.' : 'You have no saved files yet.'; };
A.code_insert = async ({ text }) => {
  undo.push(ta.value);
  const s = ta.selectionStart, e = ta.selectionEnd, before = ta.value.slice(0, s);
  const t = (text === '\n' || !before || /\s$/.test(before) ? '' : ' ') + text;
  ta.setRangeText(t, s, e, 'end'); ta.focus(); return 'Typed.';
};
A.code_explain = async () => {
  if(!ta.value.trim()) return 'The editor is empty.';
  if(!cfg.key) return 'Add your AI key in settings and I can explain code.';
  O.setState('thinking');
  try{ return await O.chat([{ role:'user', content:ta.value.slice(0, 6000) }], 'Explain this code in two or three short spoken sentences. No markdown.'); }
  catch(e){ return 'AI error: ' + e.message; }
};

O.codeAI = async req => {
  if(!cfg.key) return 'Add your AI key in settings and I can write code for you. You can still dictate with "type" followed by the text.';
  O.setState('thinking');
  const sys = 'You are the coding assistant inside a voice-controlled editor. Return the COMPLETE updated file in one fenced code block, then ONE short spoken sentence about what you did. Prefer a single self-contained HTML file with inline CSS and JS unless another language is requested.';
  const cur = ta.value.trim();
  let reply;
  try{ reply = await O.chat([{ role:'user', content:(cur ? 'Current file:\n```\n' + cur + '\n```\n' : '') + 'Request: ' + req }], sys); }
  catch(e){ return 'AI error: ' + e.message; }
  const m = /```[\w+-]*\n([\s\S]*?)```/.exec(reply);
  if(!m) return reply.slice(0, 300);
  code.set(m[1].replace(/\n$/, ''));
  const say = reply.replace(m[0], '').trim().split('\n').filter(Boolean).pop() || 'Done.';
  if(isHtml(ta.value)) run();
  return say.slice(0, 220);
};
O.codeFallback = text => O.codeAI(text);
A.code_ai = async ({ request }) => O.codeAI(request);
A.code_gen = async ({ request }) => { await A.view({ name:'code' }); return O.codeAI(request); };

/* Phrases that only make sense while the editor is open. */
O.codeRoute = s => {
  let m;
  if(/^(?:run|execute|test)(?: it| (?:the )?(?:code|program|page|app))?$/i.test(s)) return go('code_run');
  if(/^copy(?: (?:the )?(?:code|all|it))?$/i.test(s)) return go('code_copy');
  if(/^undo(?: that| last| change)?$/i.test(s)) return go('code_undo');
  if(/^(?:clear|erase|delete)(?: (?:the )?(?:code|editor|everything|all))?$|^new (?:file|project)$/i.test(s)) return go('code_clear');
  if((m = /^save(?: (?:it|file|code))?(?: as (.+))?$/i.exec(s))) return go('code_save', { name:m[1] });
  if((m = /^(?:open|load) (?:file |project )?(?:called |named )?(.+)$/i.exec(s)) && fileKey(m[1]) in files()) return go('code_load', { name:m[1] });
  if(/^(?:list|show) (?:my )?(?:files|projects|saved files)$/i.test(s)) return go('code_list');
  if((m = /^(?:type|insert|dictate)\s+(.+)$/i.exec(s))) return go('code_insert', { text:m[1] });
  if(/^new line$/i.test(s)) return go('code_insert', { text:'\n' });
  if(/^(?:explain|read|describe)(?: this| the| my)?(?: code| program| file)?$|^what does (?:this|it) do$/i.test(s)) return go('code_explain');
  if(/^(?:fix|debug)(?: this| the| my)?(?: code| bug| error)?s?$/i.test(s)) return go('code_ai', { request:'Find and fix any bugs in this code.' });
  if(/^(?:close|exit|leave)(?: the)?(?: code)?(?: editor)?$/i.test(s)) return go('view', { name:'home' });
  return null;
};

document.querySelectorAll('#ctool .tb').forEach(b => b.onclick = async () => {
  const c = b.dataset.c, fn = { run:'code_run', copy:'code_copy', undo:'code_undo', clear:'code_clear', save:'code_save', files:'code_list' }[c];
  O.say(await A[fn]({}));
});
})();

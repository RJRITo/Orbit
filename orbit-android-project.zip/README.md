# ORBIT 2 — voice-only phone assistant (no time limit)

Say **"hey orbit"** (or "orbit" / "jarvis"), then speak. Everything below works by voice once permissions are granted.

## Get the APK (no Android Studio needed)
1. Create a free GitHub repo and upload this folder's contents (keep the `.github` folder).
2. Actions tab -> "Build APK" -> Run workflow. It downloads the offline wake-word model itself.
3. Download `orbit-apk`, unzip, install `app-debug.apk` (allow unknown sources).

## One-time setup (needs fingers once, then never again)
Open ORBIT -> allow the pop-ups -> gear icon -> tap each red chip:
- **Screen control** (accessibility): tap/scroll/type/back/home/quick-settings by voice
- **Open apps from background** (overlay) and **Battery unrestricted**: so it works with the screen off
- Optional: **Brightness**, contacts/calls/SMS (asked when first used)
Then add your own free Groq or Gemini key under "Brain" for open conversation and fuzzy commands.
Keep ORBIT in recent apps (don't swipe it away) so it can keep listening.

## Voice commands (no AI key needed)
- Apps: "open YouTube", "launch WhatsApp"
- People: "call Mom", "text Mom saying I'm late", "WhatsApp Rahul saying hello" (asks to confirm first)
- Hardware: "flashlight on", "volume up / set volume to 40", "brightness 70", "mute"
- Media: "pause", "next song", "play lofi" (YouTube), "play X on Spotify"
- Time: "set a timer for 10 minutes", "set an alarm for 6:30 pm", "what time is it"
- Toggles: "turn off wifi", "bluetooth on", "airplane mode on", "do not disturb on"
- Screen: "go back", "go home", "recent apps", "notifications", "screenshot", "lock the screen",
  "scroll down", "tap Login", "type hello", "press enter", "read the screen"
- Web/maps: "search for ...", "navigate to ...", "weather in Kolkata"
- Screens: "show HUD", "robot face", "code editor", "standby mode", "show the orb"
- Code editor: "write an HTML page with a bouncing ball", "run it", "fix this code", "save as pong", "undo"
- Anything else goes to the AI (needs your key), including Hindi/Bengali (set Speech language in settings)
- "go to sleep" = back to wake-word mode; "stop listening" = voice off completely

## Notes
- Wake word is offline (Vosk, silent, no beeps). Commands use Android's recogniser (online, any language) unless you tick "offline commands" (English).
- Quick-settings toggles and "tap by name" depend on your phone's labels; they are best-effort.
- Not tested on a physical phone yet.
